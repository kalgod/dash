angular.module('DashCastReceiverApp', [
  'DashCastReceiverApp.controllers',
  'DashCastReceiverApp.services'
]);