angular.module('DashCastSenderApp', [
  'DashCastSenderApp.controllers',
  'DashCastSenderApp.services'
]);