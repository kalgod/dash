# Dash.js Authors List
#####Please add entries to the bottom of the list in the following format
* @GitHub UserName (Required) [Name and/or Organization] (Optional)

#Authors 
* @nweber [Digital Primates]
* @jefftapper [Jeff Tapper, Digital Primates]
* @KozhinM [Mikail Kozhin, Microsoft Open Technologies]
* @kirkshoop [Kirk Shoop, Microsoft Open Technologies]
* @wilaw [Will Law, Akamai Technologies]
* @AkamaiDASH [Dan Sparacio, Akamai Technologies]
* @dsilhavy [Daniel Silhavy, Fraunhofer Fokus]
* @greg80303 [Greg Rutz, CableLabs]
* @heff [Steve Hefferman, Brightcove]
* @Tomjohnson916 [Tom Johnson, Brightcove]
* @jeroenwiljering [Jeroen Wijering, JWPlayer]
* @bbcrddave [David Evans, BBC R&D]
* @bbert [Bertrand Berthelot, Orange]
* @vigneshvg [Vignesh Venkatasubramanian, Google]
* @nicosang [Nicolas Angot, Orange]
* @PriyadarshiniV
* @senthil-codr [Senthil]
* @dweremeichik [Dylan Weremeichik]
* @aleal-envivio 
* @mconlin
* @umavinoth
* @lbonn
* @mdale [Michael Dale, Kaltura]
* @sgrebnov [Sergey Grebnov, Microsoft Open Technologies]
* @wesleytodd [Wes Todd, Vubeology]
* @colde [Loke Dupont, Xstream]
* @rgardler [Ross Gardler, Microsoft Open Technologies]
* @squapp
* @xiaomings
* @rcollins112 [Rich Collins, Wowza]
* @timothy003 [Timothy Liang]
* @JaapHaitsma
* @72lions [Thodoris Tsiridis, 72lions]
* @TobbeMobiTV [Torbjörn Einarsson, MobiTV]
* @TobbeEdgeware [Torbjörn Einarsson, Edgeware]
* @mstorsjo [Martin Storsjö]
* @Hyddan [Daniel Hedenius]
* @qjia7
* @waqarz
* @WMSPanel [WMSPanel Team]
* @matt-hammond-bbc [Matt Hammond, BBC R&D]
* @siropeich [Siro Blanco, Epic Labs]
* @epiclabsDASH [Jesus Oliva, Epic Labs]
* @adripanico [Adrian Caballero, Epic Labs]
* @ahfarmer [Andrew Farmer, Rhombus Systems]
* @matvp91 [Matthias Van Parijs]
