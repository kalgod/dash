const VERSION = '__VERSION__';
export function getVersionString() {
    return VERSION;
}
